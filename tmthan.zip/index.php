<?php get_header(); ?>
<noscript><strong>We're sorry but wptheme doesn't work properly without JavaScript enabled. Please enable it to continue.</strong></noscript>
<div id="app"></div>
<script src="/wp-content/themes/tmthan/dist/js/tmthan.chunk-vendors.js"></script>
<script src="/wp-content/themes/tmthan/dist/js/tmthan.app.js"></script>
<?php get_footer();
