<template>
    <footer class="footer">
        Make width
        <svg xmlns="http://www.w3.org/2000/svg" style="width: 24px; height: 24px; margin: 0 10px;" viewBox="0 0 24 24"><g data-name="Layer 2"><g data-name="heart"><rect width="24" height="24" opacity="0"/><path d="M12 21a1 1 0 0 1-.71-.29l-7.77-7.78a5.26 5.26 0 0 1 0-7.4 5.24 5.24 0 0 1 7.4 0L12 6.61l1.08-1.08a5.24 5.24 0 0 1 7.4 0 5.26 5.26 0 0 1 0 7.4l-7.77 7.78A1 1 0 0 1 12 21zM7.22 6a3.2 3.2 0 0 0-2.28.94 3.24 3.24 0 0 0 0 4.57L12 18.58l7.06-7.07a3.24 3.24 0 0 0 0-4.57 3.32 3.32 0 0 0-4.56 0l-1.79 1.8a1 1 0 0 1-1.42 0L9.5 6.94A3.2 3.2 0 0 0 7.22 6z"/></g></g></svg>
        since 2015
    </footer>
</template>
<script>
export default {
    name: 'Footer',
}
</script>
<style lang="scss" scoped>
.footer {
    padding: 30px;
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 16px;
}
</style>